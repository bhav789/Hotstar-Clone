# hotstar
Images-and videos
*Hotstar Clone*| Developer	
Duration: 7 days
Environment: Windows
Languages/Database: HTML | CSS | Javascript
Team Size: Individual
The Hotstar Clone project is a front-end web development project that is designed to display a carousel of movies and TV shows. The project uses HTML, CSS, and JavaScript to create a responsive and visually appealing user interface.

